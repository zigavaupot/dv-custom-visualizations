define({
  "root": true,
  "sl": true  // Slovenian
});
