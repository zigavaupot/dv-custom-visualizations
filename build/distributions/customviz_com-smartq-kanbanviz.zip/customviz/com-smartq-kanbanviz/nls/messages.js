define({
  "root": true,
  "sl": true,  // Slovenian
  "fr": true,  // French
  "de": true,  // German
  "es": true,  // Spanish
  "hr": true,  // Croatian
  "it": true   // Italian
});
