define({
    "CIRCLEPACK_DISPLAY_NAME": "Kreis-Pack",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Kreis-Pack",
    "CIRCLEPACK_CATEGORY":"Kreis-Pack",
    "CIRCLEPACK_ROW_LABEL":"Kreise",
    "CIRCLEPACK_CIRCLE_SIZE":"Kreisgröße",
    "TEXT_MESSAGE": "Hallo! Dies ist die {0}-Visualisierung, es sind {1} Datenzeilen vorhanden."
});
