define({
    "CIRCLEPACK_DISPLAY_NAME": "Balenie kruhov",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Balenie kruhov",
    "CIRCLEPACK_CATEGORY":"Balenie kruhov",
    "CIRCLEPACK_ROW_LABEL":"Kruhy",
    "CIRCLEPACK_CIRCLE_SIZE":"Veľkosť kruhu",
    "TEXT_MESSAGE": "Vitajte! Toto je vizualizácia {0} s dátami v {1} riadkoch."
});
