define({
    "CIRCLEPACK_DISPLAY_NAME": "Kružno pakiranje",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Kružno pakiranje",
    "CIRCLEPACK_CATEGORY":"Kružno pakiranje",
    "CIRCLEPACK_ROW_LABEL":"Krugovi",
    "CIRCLEPACK_CIRCLE_SIZE":"Veličina kruga",
    "TEXT_MESSAGE": "Pozdrav! ovo je vizualizacija {0} i imam sljedeći broj redaka s podacima: {1}."
});
