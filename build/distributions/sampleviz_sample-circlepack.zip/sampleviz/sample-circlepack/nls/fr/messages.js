define({
    "CIRCLEPACK_DISPLAY_NAME": "Pack de cercles",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Pack de cercles",
    "CIRCLEPACK_CATEGORY":"Pack de cercles",
    "CIRCLEPACK_ROW_LABEL":"Cercles",
    "CIRCLEPACK_CIRCLE_SIZE":"Taille de cercle",
    "TEXT_MESSAGE": "Bonjour. Voici la visualisation {0} et j'ai {1} lignes de données."
});
