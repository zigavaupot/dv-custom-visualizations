define({
    "CIRCLEPACK_DISPLAY_NAME": "Ensemble de cercles",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Ensemble de cercles",
    "CIRCLEPACK_CATEGORY":"Ensemble de cercles",
    "CIRCLEPACK_ROW_LABEL":"Cercles",
    "CIRCLEPACK_CIRCLE_SIZE":"Taille de cercle",
    "TEXT_MESSAGE": "Bonjour! Je suis la visualisation {0} et je dispose de {1} rangées de données."
});
