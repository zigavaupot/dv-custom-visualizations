define({
    "CIRCLEPACK_DISPLAY_NAME": "Circle Pack",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Circle Pack",
    "CIRCLEPACK_CATEGORY":"Circle Pack",
    "CIRCLEPACK_ROW_LABEL":"Kręgi",
    "CIRCLEPACK_CIRCLE_SIZE":"Rozmiar kręgu",
    "TEXT_MESSAGE": "To jest wizualizacja \"{0}\"; istnieją {1} wiersze(-y) danych."
});
