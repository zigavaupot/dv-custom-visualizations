define({
    "CIRCLEPACK_DISPLAY_NAME": "Pacote de Círculos",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Pacote de Círculos",
    "CIRCLEPACK_CATEGORY":"Pacote de Círculos",
    "CIRCLEPACK_ROW_LABEL":"Círculos",
    "CIRCLEPACK_CIRCLE_SIZE":"Tamanho do Círculo",
    "TEXT_MESSAGE": "Olá! Esta é a visualização de {0} e eu tenho {1} linhas de dados."
});
