define({
    "CIRCLEPACK_DISPLAY_NAME": "Pachet de cercuri",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Pachet de cercuri",
    "CIRCLEPACK_CATEGORY":"Pachet de cercuri",
    "CIRCLEPACK_ROW_LABEL":"Cercuri",
    "CIRCLEPACK_CIRCLE_SIZE":"Dimensiune cerc",
    "TEXT_MESSAGE": "Bună. Aceasta este vizualizarea {0} şi am {1} rânduri de date."
});
