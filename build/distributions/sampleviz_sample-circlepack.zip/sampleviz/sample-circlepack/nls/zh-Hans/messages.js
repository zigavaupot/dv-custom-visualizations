define({
    "CIRCLEPACK_DISPLAY_NAME": "圆形包",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "圆形包",
    "CIRCLEPACK_CATEGORY":"圆形包",
    "CIRCLEPACK_ROW_LABEL":"圆形",
    "CIRCLEPACK_CIRCLE_SIZE":"圆形大小",
    "TEXT_MESSAGE": "你好! 这是 {0} 显示形式, 并且我有 {1} 行数据。"
});
