define({
    "CIRCLEPACK_DISPLAY_NAME": "圓圈圖",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "圓圈圖",
    "CIRCLEPACK_CATEGORY":"圓圈圖",
    "CIRCLEPACK_ROW_LABEL":"圓圈",
    "CIRCLEPACK_CIRCLE_SIZE":"圓圈大小",
    "TEXT_MESSAGE": "您好!  這是 {0} 視覺化, 我有 {1} 個資料列的資料."
});
