define({
    "CIRCLEPACK_DISPLAY_NAME": "Sirkelpakke",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Sirkelpakke",
    "CIRCLEPACK_CATEGORY":"Sirkelpakke",
    "CIRCLEPACK_ROW_LABEL":"Sirkler",
    "CIRCLEPACK_CIRCLE_SIZE":"Sirkelstørrelse",
    "TEXT_MESSAGE": "Hei! Dette er visualiseringen {0}, og jeg har {1} rader med data."
});
