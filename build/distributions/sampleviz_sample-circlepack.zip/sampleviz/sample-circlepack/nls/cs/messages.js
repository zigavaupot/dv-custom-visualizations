define({
    "CIRCLEPACK_DISPLAY_NAME": "Balík kruhu",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Balík kruhu",
    "CIRCLEPACK_CATEGORY":"Balík kruhu",
    "CIRCLEPACK_ROW_LABEL":"Kruhy",
    "CIRCLEPACK_CIRCLE_SIZE":"Velikost kruhu",
    "TEXT_MESSAGE": "Dobrý den!  Je to vizualizace {0}, která má následující počet řádků dat: {1}."
});
