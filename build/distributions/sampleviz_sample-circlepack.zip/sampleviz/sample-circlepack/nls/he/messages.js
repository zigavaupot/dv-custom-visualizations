define({
    "CIRCLEPACK_DISPLAY_NAME": "אריזה מעגלית",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "אריזה מעגלית",
    "CIRCLEPACK_CATEGORY":"אריזה מעגלית",
    "CIRCLEPACK_ROW_LABEL":"מעגלים",
    "CIRCLEPACK_CIRCLE_SIZE":"גודל מעגל",
    "TEXT_MESSAGE": "שלום!  זוהי ההמחשה הגרפית {0} ויש לי {1} שורות נתונים."
});
