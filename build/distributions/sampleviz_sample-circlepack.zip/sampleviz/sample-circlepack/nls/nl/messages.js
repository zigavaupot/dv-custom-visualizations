define({
    "CIRCLEPACK_DISPLAY_NAME": "Cirkelpatroon",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Cirkelpatroon",
    "CIRCLEPACK_CATEGORY":"Cirkelpatroon",
    "CIRCLEPACK_ROW_LABEL":"Cirkels",
    "CIRCLEPACK_CIRCLE_SIZE":"Cirkelgrootte",
    "TEXT_MESSAGE": "Dit is de {0} visualisatie. Deze heeft {1} rijen met gegevens."
});
