define({
    "CIRCLEPACK_DISPLAY_NAME": "원 팩",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "원 팩",
    "CIRCLEPACK_CATEGORY":"원 팩",
    "CIRCLEPACK_ROW_LABEL":"원",
    "CIRCLEPACK_CIRCLE_SIZE":"원 크기",
    "TEXT_MESSAGE": "안녕하세요! 이 항목은 {0} 시각화이며 {1}개의 데이터 행이 있습니다."
});
