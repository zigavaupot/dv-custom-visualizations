define({
    "CIRCLEPACK_DISPLAY_NAME": "Pacchetto di cerchi",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Pacchetto di cerchi",
    "CIRCLEPACK_CATEGORY":"Pacchetto di cerchi",
    "CIRCLEPACK_ROW_LABEL":"Cerchi",
    "CIRCLEPACK_CIRCLE_SIZE":"Dimensioni cerchio",
    "TEXT_MESSAGE": "Questa è la visualizzazione di {0} e sono disponibili {1} righe di dati."
});
