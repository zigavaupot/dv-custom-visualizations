define({
    "CIRCLEPACK_DISPLAY_NAME": "Cirkelpakke",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Cirkelpakke",
    "CIRCLEPACK_CATEGORY":"Cirkelpakke",
    "CIRCLEPACK_ROW_LABEL":"Cirkler",
    "CIRCLEPACK_CIRCLE_SIZE":"Cirkelstørrelse",
    "TEXT_MESSAGE": "Hej! Dette er {0}-visualiseringen, og jeg har {1} rækker med data."
});
