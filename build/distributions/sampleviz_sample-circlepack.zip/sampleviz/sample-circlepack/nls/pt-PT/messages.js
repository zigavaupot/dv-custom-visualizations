define({
    "CIRCLEPACK_DISPLAY_NAME": "Conjunto de Círculos",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Conjunto de Círculos",
    "CIRCLEPACK_CATEGORY":"Conjunto de Círculos",
    "CIRCLEPACK_ROW_LABEL":"Círculos",
    "CIRCLEPACK_CIRCLE_SIZE":"Tamanho dos Círculos",
    "TEXT_MESSAGE": "Olá! Esta é a visualização {0} e tenho {1} linhas de dados."
});
