define({
    "CIRCLEPACK_DISPLAY_NAME": "Ympyräladonta",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Ympyräladonta",
    "CIRCLEPACK_CATEGORY":"Ympyräladonta",
    "CIRCLEPACK_ROW_LABEL":"Ympyrät",
    "CIRCLEPACK_CIRCLE_SIZE":"Ympyrän koko",
    "TEXT_MESSAGE": "Hei! Tämä on kohteen {0} visualisointi. Tietorivejä on {1}."
});
