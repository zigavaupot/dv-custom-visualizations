define({
    "CIRCLEPACK_DISPLAY_NAME": "Circle Pack",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Circle Pack",
    "CIRCLEPACK_CATEGORY":"Circle Pack",
    "CIRCLEPACK_ROW_LABEL":"Körök",
    "CIRCLEPACK_CIRCLE_SIZE":"Kör mérete",
    "TEXT_MESSAGE": "Szia! Ez a(z) {0} megjelenítés, és nálam {1} sornyi adat van."
});
