define({
    "CIRCLEPACK_DISPLAY_NAME": "Daire Grubu",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Daire Grubu",
    "CIRCLEPACK_CATEGORY":"Daire Grubu",
    "CIRCLEPACK_ROW_LABEL":"Daireler",
    "CIRCLEPACK_CIRCLE_SIZE":"Daire Boyutu",
    "TEXT_MESSAGE": "Merhaba! Bu {0} görselleştirmesidir ve {1} veri satırı var."
});
