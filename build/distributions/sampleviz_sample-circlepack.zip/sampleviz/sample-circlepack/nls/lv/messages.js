define({
    "CIRCLEPACK_DISPLAY_NAME": "Circle Pack",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Circle Pack",
    "CIRCLEPACK_CATEGORY":"Circle Pack",
    "CIRCLEPACK_ROW_LABEL":"Circles",
    "CIRCLEPACK_CIRCLE_SIZE":"Circle Size",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."
});
