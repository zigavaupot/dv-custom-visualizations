define({
    "CIRCLEPACK_DISPLAY_NAME": "แพ็ควงกลม",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "แพ็ควงกลม",
    "CIRCLEPACK_CATEGORY":"แพ็ควงกลม",
    "CIRCLEPACK_ROW_LABEL":"วงกลม",
    "CIRCLEPACK_CIRCLE_SIZE":"ขนาดวงกลม",
    "TEXT_MESSAGE": "สวัสดี นี่คือการแสดงข้อมูล {0} และฉันมีแถวข้อมูล {1} แถว"
});
