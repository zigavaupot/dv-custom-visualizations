define({
    "CIRCLEPACK_DISPLAY_NAME": "Cirkelpaket",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Cirkelpaket",
    "CIRCLEPACK_CATEGORY":"Cirkelpaket",
    "CIRCLEPACK_ROW_LABEL":"Cirklar",
    "CIRCLEPACK_CIRCLE_SIZE":"Cirkelstorlek",
    "TEXT_MESSAGE": "Hej! Jag är visualiseringen {0} och jag har {1} rader med data."
});
