define({
    "CIRCLEPACK_DISPLAY_NAME": "Πακέτο κύκλου",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Πακέτο κύκλου",
    "CIRCLEPACK_CATEGORY":"Πακέτο κύκλου",
    "CIRCLEPACK_ROW_LABEL":"Κύκλοι",
    "CIRCLEPACK_CIRCLE_SIZE":"Μέγεθος κύκλου",
    "TEXT_MESSAGE": "Γεια σας!  Αυτή είναι η απεικόνιση {0} και έχω {1} γραμμές δεδομένων."
});
