define({
    "CIRCLEPACK_DISPLAY_NAME": "Circle Pack",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "Circle Pack",
    "CIRCLEPACK_CATEGORY":"Circle Pack",
    "CIRCLEPACK_ROW_LABEL":"Круги",
    "CIRCLEPACK_CIRCLE_SIZE":"Размер круга",
    "TEXT_MESSAGE": "Здравствуйте! Это визуализация {0}, и имеются строки данных ({1})."
});
