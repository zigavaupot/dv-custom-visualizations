define({
    "CIRCLEPACK_DISPLAY_NAME": "円パッキング",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "円パッキング",
    "CIRCLEPACK_CATEGORY":"円パッキング",
    "CIRCLEPACK_ROW_LABEL":"円",
    "CIRCLEPACK_CIRCLE_SIZE":"円のサイズ",
    "TEXT_MESSAGE": "Hello!  これは{0}のビジュアライゼーションで、{1}行のデータがあります。"
});
