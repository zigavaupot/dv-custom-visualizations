define({
    "CIRCLEPACK_DISPLAY_NAME": "حزمة الدوائر",
    "CIRCLEPACK_SHORT_DISPLAY_NAME": "حزمة الدوائر",
    "CIRCLEPACK_CATEGORY":"حزمة الدوائر",
    "CIRCLEPACK_ROW_LABEL":"دوائر",
    "CIRCLEPACK_CIRCLE_SIZE":"حجم الدائرة",
    "TEXT_MESSAGE": "مرحبًا!  هذا تمثيل مرئي لـ {0} وهناك {1} من صفوف البيانات."
});
